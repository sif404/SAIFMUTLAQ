package com.example.inventory.ui.home

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.inventory.data.Item
import com.example.inventory.data.ItemsRepository
import com.example.inventory.data.CategoriesRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

class HomeViewModel(
    savedStateHandle: SavedStateHandle,
    itemsRepository: ItemsRepository,
    categoriesRepository: CategoriesRepository
) : ViewModel() {

    private val categoryId: Int = checkNotNull(savedStateHandle[HomeDestination.categoryIdArg])

    val homeUiState: StateFlow<HomeUiState> =
        combine(
            itemsRepository.getItemsByCategoryStream(categoryId),
            categoriesRepository.getCategoryStream(categoryId)
        ) { items, category ->
            HomeUiState(itemList = items, categoryName = category?.name ?: "")
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000L),
            initialValue = HomeUiState()
        )

    companion object {
        private const val TIMEOUT_MILLIS = 5_000L
    }
}

data class HomeUiState(
    val itemList: List<Item> = listOf(),
    val categoryName: String = ""
)
