package com.example.inventory.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.example.inventory.ui.category.CategoryEntryDestination
import com.example.inventory.ui.category.CategoryEntryScreen
import com.example.inventory.ui.category.CategoryListDestination
import com.example.inventory.ui.category.CategoryListScreen
import com.example.inventory.ui.home.HomeDestination
import com.example.inventory.ui.home.HomeScreen
import com.example.inventory.ui.item.ItemDetailsDestination
import com.example.inventory.ui.item.ItemDetailsScreen
import com.example.inventory.ui.item.ItemEditDestination
import com.example.inventory.ui.item.ItemEditScreen
import com.example.inventory.ui.item.ItemEntryDestination
import com.example.inventory.ui.item.ItemEntryScreen

@Composable
fun InventoryNavHost(
    navController: NavHostController,
    modifier: Modifier = Modifier,
) {
    NavHost(
        navController = navController,
        startDestination = CategoryListDestination.route,
        modifier = modifier
    ) {
        // Screen 1: Category List (start screen)
        composable(route = CategoryListDestination.route) {
            CategoryListScreen(
                navigateToCategoryEntry = { navController.navigate(CategoryEntryDestination.route) },
                navigateToItemList = { categoryId ->
                    navController.navigate("${HomeDestination.route}/$categoryId")
                }
            )
        }

        // Screen 2: Add Category
        composable(route = CategoryEntryDestination.route) {
            CategoryEntryScreen(
                navigateBack = { navController.popBackStack() },
                onNavigateUp = { navController.navigateUp() }
            )
        }

        // Screen 3: Items list for a category
        composable(
            route = HomeDestination.routeWithArgs,
            arguments = listOf(navArgument(HomeDestination.categoryIdArg) {
                type = NavType.IntType
            })
        ) { backStackEntry ->
            val categoryId = backStackEntry.arguments?.getInt(HomeDestination.categoryIdArg) ?: 0
            HomeScreen(
                navigateToItemEntry = {
                    navController.navigate("${ItemEntryDestination.route}/$categoryId")
                },
                navigateToItemUpdate = { itemId ->
                    navController.navigate("${ItemDetailsDestination.route}/$itemId")
                },
                navigateBack = { navController.navigateUp() }
            )
        }

        // Screen 4: Add Item (with categoryId)
        composable(
            route = ItemEntryDestination.routeWithArgs,
            arguments = listOf(navArgument(ItemEntryDestination.categoryIdArg) {
                type = NavType.IntType
            })
        ) {
            ItemEntryScreen(
                navigateBack = { navController.popBackStack() },
                onNavigateUp = { navController.navigateUp() }
            )
        }

        // Screen 5: Item Details
        composable(
            route = ItemDetailsDestination.routeWithArgs,
            arguments = listOf(navArgument(ItemDetailsDestination.itemIdArg) {
                type = NavType.IntType
            })
        ) {
            ItemDetailsScreen(
                navigateToEditItem = { navController.navigate("${ItemEditDestination.route}/$it") },
                navigateBack = { navController.navigateUp() }
            )
        }

        // Screen 6: Edit Item
        composable(
            route = ItemEditDestination.routeWithArgs,
            arguments = listOf(navArgument(ItemEditDestination.itemIdArg) {
                type = NavType.IntType
            })
        ) {
            ItemEditScreen(
                navigateBack = { navController.popBackStack() },
                onNavigateUp = { navController.navigateUp() }
            )
        }
    }
}
