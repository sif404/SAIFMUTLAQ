package com.example.inventory.ui.category

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.example.inventory.data.CategoriesRepository
import com.example.inventory.data.Category

class CategoryEntryViewModel(
    private val categoriesRepository: CategoriesRepository
) : ViewModel() {

    var categoryName by mutableStateOf("")
        private set

    fun updateName(name: String) {
        categoryName = name
    }

    suspend fun saveCategory() {
        if (categoryName.isNotBlank()) {
            categoriesRepository.insertCategory(Category(name = categoryName))
        }
    }
}
