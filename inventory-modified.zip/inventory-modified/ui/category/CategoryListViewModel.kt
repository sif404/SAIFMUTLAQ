package com.example.inventory.ui.category

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.inventory.data.Category
import com.example.inventory.data.CategoriesRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

class CategoryListViewModel(
    private val categoriesRepository: CategoriesRepository
) : ViewModel() {

    val uiState: StateFlow<CategoryListUiState> =
        categoriesRepository.getAllCategoriesStream()
            .map { CategoryListUiState(it) }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5_000L),
                initialValue = CategoryListUiState()
            )
}

data class CategoryListUiState(val categoryList: List<Category> = listOf())
