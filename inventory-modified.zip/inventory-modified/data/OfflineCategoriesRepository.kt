package com.example.inventory.data

import kotlinx.coroutines.flow.Flow

class OfflineCategoriesRepository(private val categoryDao: CategoryDao) : CategoriesRepository {
    override fun getAllCategoriesStream(): Flow<List<Category>> = categoryDao.getAllCategories()
    override fun getCategoryStream(id: Int): Flow<Category?> = categoryDao.getCategory(id)
    override suspend fun insertCategory(category: Category) = categoryDao.insert(category)
    override suspend fun deleteCategory(category: Category) = categoryDao.delete(category)
    override suspend fun updateCategory(category: Category) = categoryDao.update(category)
}
